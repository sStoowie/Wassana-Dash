
package tile;

import java.awt.image.BufferedImage;

public class Tile {
    //for edit image (resize)
    public BufferedImage image;
    //can pass this area
    public boolean collision = false;
}

package entity;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import main.CustomerACooldown;
import main.CustomerBCooldown;
import main.CustomerCCooldown;
import main.CustomerDCooldown;
import main.GamePanel;
import main.tableBCooldown;
import object.TablewithCust;
import object.topTablewithCust;

//stories variables that be used in Player , Customer Class
public class Entity {
    GamePanel gp;
    public int x, y;
    public int speed;
    public int moodA, moodB, moodC, moodD;
    
    CustomerACooldown custACooldown = new CustomerACooldown(5000);
    CustomerBCooldown custBCooldown = new CustomerBCooldown(5000); 
    CustomerCCooldown custCCooldown = new CustomerCCooldown(5000); 
    CustomerDCooldown custDCooldown = new CustomerDCooldown(5000); 
    
  
    
    //image
    public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2, walk1, walk2, walk3, walk4;
    public BufferedImage updish1, updish2, downdish1, downdish2, leftdish1, leftdish2, rightdish1, rightdish2;
    public String direction;
   
    
    //make animation : change pic
    public int spriteCounter = 0;
    public int spriteNum = 1;
    
    //solid Tiles
    public Rectangle solidArea = new Rectangle(0, 0, 48, 48);
    //solid oject
    public int solidAreaDefaultX, solidAreaDefaultY;
    public boolean collisionOn = false;
    
    //for customer
//    public int heart;
//    public String state;
    public int width, height;
    public boolean hasTable;
//    public boolean hasline;
    
    
    public Entity(GamePanel gp){
        this.gp = gp;
    }
    
    
    public void update(){
        //setAction();
        collisionOn = false;
        gp.cChecker.checkTile(this);
        gp.cChecker.checkObject(this, false);
        gp.cChecker.checkPlayer(this);
        
        // no line and table A
            if(collisionOn == false && gp.obj[1].empty == true && hasTable == false){
                if(y == 0){
                    gp.playSoundFX(2);                    
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    
                    
                }
                if(y != 190 && y != 210){
                    y += speed;
                    spriteCounter++;
                }
                else if(x != 128){
                    if(direction != "to"){
                        direction = "to";
                        y += 20;
                    }
                    x += speed;
                    spriteCounter++;
                }
                else{
                    System.out.println("have customer at A");
                    direction = "";
                    solidArea.height = 0;
                    solidArea.width = 0;
                    System.out.println(gp.obj[1].empty);
                    hasTable = true;
                    //table A with Customer
                    try {
                        gp.obj[1].image = ImageIO.read(new File("res/objects/TablewithCust.png"));
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custACooldown.startCooldown();
                    gp.obj[1].empty = false;
                    gp.player.tableAPhase = 1;
                }
            }
            
            // no line and table B
            else if(collisionOn == false && gp.obj[2].empty == true && hasTable == false ){
                if(y == 0){
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                }
                if(y != 110 && y!= 130){
                    y += speed;
                    spriteCounter++;
                }
                else if(x != 403){
                   
                    if(direction != "to"){
                        direction = "to";
                        y += 20;
                    }
                    x += speed;
                    spriteCounter++;
                }
                else{
                    System.out.println("have customer at B");
                    direction = "";
                    solidArea.height = 0;
                    solidArea.width = 0;
//                   gp.obj[2].empty = false;
                    hasTable = true;
                    
                    try {
                        gp.obj[2].image = ImageIO.read(new File("res/objects/TablewithCust.png"));
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                      custBCooldown.startCooldown();
//                    gp.obj[22] = new TablewithCust();
//                    gp.obj[22].x = 11 * gp.tileSize - 14;
//                    gp.obj[22].y = 3 * gp.tileSize + 14;
                      gp.obj[2].empty = false;
                      gp.player.tableBPhase = 1;
                      
//                    gp.obj[32] = new topTablewithCust();
//                    gp.obj[32].x = 11 * gp.tileSize - 14;
//                    gp.obj[32].y = 3 * gp.tileSize + 14;
                    

                    
                }
            }
        
        // no line and table C
            else if(collisionOn == false && gp.obj[3].empty == true && hasTable == false){
                if(y == 0){
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                }
                
                if(y != 400 && y != 420){
                
                    y += speed;
                    spriteCounter++;
                }
                else if(x != 123){
                    if(direction != "to"){
                        direction = "to";
                        y += 20;
                    }
                    x += speed;
                    spriteCounter++;
                }
                else{
                    System.out.println("have customer at C");
                    direction = "";
                    solidArea.height = 0;
                    solidArea.width = 0;
//                    gp.obj[3].empty = false;
                    hasTable = true;
//                    gp.obj[23] = new TablewithCust();
//                    gp.obj[23].x = 5 * gp.tileSize + 13;
//                    gp.obj[23].y = 7 * gp.tileSize + 7;
                    try {
                        gp.obj[3].image = ImageIO.read(new File("res/objects/TablewithCust.png"));
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custCCooldown.startCooldown();
                    gp.obj[3].empty = false;
                    gp.player.tableCPhase = 1;
                    
//                    gp.obj[33] = new topTablewithCust();
//                    gp.obj[33].x = 5 * gp.tileSize + 13;
//                    gp.obj[33].y = 7 * gp.tileSize + 7;
                }
            }
            
         // no line and table D
            else if(collisionOn == false && gp.obj[4].empty == true && hasTable == false){
                if(y == 0){
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                    gp.playSoundFX(2);
                }
                if(y != 300 && y != 320){
                    y += speed;
                    spriteCounter++;
                }
                else if(x != 403){
                    if(direction != "to"){
                        direction = "to";
                        y += 20;
                    }
                    x += speed;
                    spriteCounter++;
                }
                else{
                    System.out.println("have customer at D");
                    direction = "";
                    solidArea.height = 0;
                    solidArea.width = 0;
//                    gp.obj[4].empty = false;
                    hasTable = true;
//                    gp.obj[24] = new TablewithCust();
//                    gp.obj[24].x = 11 * gp.tileSize - 14;
//                    gp.obj[24].y = 7 * gp.tileSize + 7;
                    try {
                        gp.obj[4].image = ImageIO.read(new File("res/objects/TablewithCust.png"));
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custDCooldown.startCooldown();
                    gp.obj[4].empty = false;
                    gp.player.tableDPhase = 1;
                    
//                    gp.obj[34] = new topTablewithCust();
//                    gp.obj[34].x = 11 * gp.tileSize - 14;
//                    gp.obj[34].y = 7 * gp.tileSize + 7;
                }
            }
            
            //no table get line
            else if(collisionOn == false && hasTable == false && gp.line == 0){
                if(y != 400){
                    y += speed;
                    spriteCounter++;
                }
                else{
                    gp.line = 1;
                    speed = 0;
//                    hasline = true;
                    spriteNum = 1;
                }
            }
            else if(collisionOn == false && hasTable == false && gp.line == 1){
                if(y != 250){
                    y += speed;
                    spriteCounter++;
                }
                else{
                    gp.line = 2;
                    speed = 0;
//                    hasline = true;
                    spriteNum = 1;
                }
            }
            else if(collisionOn == false && hasTable == false && gp.line == 2){
                if(y != 100){
                    y += speed;
                    spriteCounter++;
                }
                else{
                    gp.line = 3;
                    speed = 0;
//                    hasline = true;
                    spriteNum = 1;
                }
            }
            //spriteCounter++;
            if(spriteCounter > 12){
                if(spriteNum == 1){
                    spriteNum = 2;
                }
                else if(spriteNum == 2){
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
            // table a mood
            if(gp.player.cancelMoodA == true){
                custACooldown.cancelCooldown();
               
            }
            else{
                if(custACooldown.finishedcustA == true && moodA == 0){
                    try {
                        gp.obj[1].image = ImageIO.read(new File("res/objects/mood2.png"));
                        moodA = 2;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custACooldown.finishedcustA = false;
                    custACooldown.startCooldown();
                }
                if(custACooldown.finishedcustA == true && moodA == 2){
                    try {
                        gp.obj[1].image = ImageIO.read(new File("res/objects/mood3.png"));
                        moodA = 3;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custACooldown.finishedcustA = false;
                    custACooldown.startCooldown();
                    gp.playSoundFX(4);
                
                }
                if(custACooldown.finishedcustA == true && moodA == 3){
                    try {
                        gp.obj[1].image = ImageIO.read(new File("res/objects/table1.png"));
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custACooldown.finishedcustA = false;
                    gp.obj[1].empty = true;
                    int pos = gp.cust.size();
                    gp.cust.add(new Customer(gp));
                    gp.cust.get(pos).x = gp.tileSize * 2 - 8;
                    gp.cust.get(pos).y = 0;
                    gp.cust.get(pos).hasTable = false;
                    gp.player.tableAPhase = 0;
                    gp.playSoundFX(2);
//                    gp.cust.get(pos).hasline = false;
                    }
                }
            //////table b mood
            if(gp.player.cancelMoodB == true){
                custBCooldown.cancelCooldown();
               
            }
            else{
                if(custBCooldown.finishedcustB == true && moodB == 0){
                    try {
                        gp.obj[2].image = ImageIO.read(new File("res/objects/mood2.png"));
                        moodB = 2;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custBCooldown.finishedcustB = false;
                    custBCooldown.startCooldown();
                }
                if(custBCooldown.finishedcustB == true && moodB == 2){
                    try {
                        gp.obj[2].image = ImageIO.read(new File("res/objects/mood3.png"));
                        moodB = 3;
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custBCooldown.finishedcustB = false;
                    custBCooldown.startCooldown();
                    gp.playSoundFX(4);
                
                }
                if(custBCooldown.finishedcustB == true && moodB == 3){
                    try {
                        gp.obj[2].image = ImageIO.read(new File("res/objects/table1.png"));
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custBCooldown.finishedcustB = false;
                    gp.obj[2].empty = true;
                    int pos = gp.cust.size();
                    gp.cust.add(new Customer(gp));
                    gp.cust.get(pos).x = gp.tileSize * 2 - 8;
                    gp.cust.get(pos).y = 0;
                    gp.cust.get(pos).hasTable = false;
                    gp.player.tableBPhase = 0;
                    gp.playSoundFX(2);
//                    gp.cust.get(pos).hasline = false;
                    }
                }
            //table C mood
             if(gp.player.cancelMoodC == true){
                custCCooldown.cancelCooldown();
               
            }
            else{
                if(custCCooldown.finishedcustC == true && moodC == 0){
                    try {
                        gp.obj[3].image = ImageIO.read(new File("res/objects/mood2.png"));
                        moodC = 2;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custCCooldown.finishedcustC = false;
                    custCCooldown.startCooldown();
                }
                if(custCCooldown.finishedcustC == true && moodC == 2){
                    try {
                        gp.obj[3].image = ImageIO.read(new File("res/objects/mood3.png"));
                        moodC = 3;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    gp.playSoundFX(4);
                    custCCooldown.finishedcustC = false;
                    custCCooldown.startCooldown();
                
                }
                if(custCCooldown.finishedcustC == true && moodC == 3){
                    try {
                        gp.obj[3].image = ImageIO.read(new File("res/objects/table1.png"));
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custCCooldown.finishedcustC = false;
                    gp.obj[3].empty = true;
                    int pos = gp.cust.size();
                    gp.cust.add(new Customer(gp));
                    gp.cust.get(pos).x = gp.tileSize * 2 - 8;
                    gp.cust.get(pos).y = 0;
                    gp.cust.get(pos).hasTable = false;
                    gp.player.tableCPhase = 0;
                    gp.playSoundFX(2);
//                    gp.cust.get(pos).hasline = false;
                    }
                }
             // table D
            if(gp.player.cancelMoodD == true){
                custDCooldown.cancelCooldown();
               
            }
            else{
                if(custDCooldown.finishedcustD == true && moodD == 0){
                    try {
                        gp.obj[4].image = ImageIO.read(new File("res/objects/mood2.png"));
                        moodD = 2;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    custDCooldown.finishedcustD = false;
                    custDCooldown.startCooldown();
                }
                if(custDCooldown.finishedcustD == true && moodD == 2){
                    try {
                        gp.obj[4].image = ImageIO.read(new File("res/objects/mood3.png"));
                        moodD = 3;
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    gp.playSoundFX(4);
                    custDCooldown.finishedcustD = false;
                    custDCooldown.startCooldown();
                
                }
                if(custDCooldown.finishedcustD == true && moodD == 3){
                    try {
                        gp.obj[4].image = ImageIO.read(new File("res/objects/table1.png"));
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    custDCooldown.finishedcustD = false;
                    gp.obj[4].empty = true;
                    int pos = gp.cust.size();
                    gp.cust.add(new Customer(gp));
                    gp.cust.get(pos).x = gp.tileSize * 2 - 8;
                    gp.cust.get(pos).y = 0;
                    gp.cust.get(pos).hasTable = false;
                    gp.player.tableDPhase = 0;
                    gp.playSoundFX(2);
//                    gp.cust.get(pos).hasline = false;
                    
                    }
                }
            
 
           
    }
    
    public void draw(Graphics2D g2){
        BufferedImage image = null;
        
        switch(direction){
            case "walk":
                if(spriteNum == 1){
                    image = walk1;
                }
                if(spriteNum == 2){
                    image = walk2;
                }
                break;
            case "to":
                width = 135;
                height = 50;
                solidArea.width = width;
                solidArea.height = height;
                if(spriteNum == 1){
                    image = walk3;
                }
                if(spriteNum == 2){
                    image = walk4;
                }
                break;
//            case "down":
//                if(spriteNum == 1){
//                    image = down1;
//                }
//                if(spriteNum == 2){
//                    image = down2;
//                }
//                break;
//            case "left":
//                if(spriteNum == 1){
//                    image = left1;
//                }
//                if(spriteNum == 2){
//                    image = left2;
//                }
//                break;
//            case "right":
//                if(spriteNum == 1){
//                    image = right1;
//                }
//                if(spriteNum == 2){
//                    image = right2;
//                }
//                break;
        }
        
        //g2.drawImage(image, x, y, gp.tileSize, gp.tileSize, null);
        g2.drawImage(image, x, y, width, height, null);
    }
}

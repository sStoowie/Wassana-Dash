package main;

import java.util.Timer;
import java.util.TimerTask;

public class tableDCooldown {
    private Timer timer;
    private long cooldownDuration;
    public boolean finishedD = false;

    public tableDCooldown(long cooldownDuration) {
        this.cooldownDuration = cooldownDuration;
        this.timer = new Timer();
    }

    public void startCooldown() {
//        System.out.println("Cooldown started...");
        timer.schedule(new CooldownTask(), cooldownDuration);
    }

    private class CooldownTask extends TimerTask {
        @Override
        public void run() {
//            System.out.println("Cooldown finished. Proceeding with the next task...");
            finishedD = true;
            // ...
        }
    }

    public static void main(String[] args) {
        tableACooldown cooldown = new tableACooldown(5000); // กำหนดระยะเวลา Cooldown ในหน่วยมิลลิวินาที (ในที่นี้เป็น 5 วินาที)

        cooldown.startCooldown(); // เริ่มต้นการคูลล์ดาวน์

        // คลาสอื่นๆ ยังคงทำงานต่อไปได้โดยไม่รอคูลล์ดาวน์
        // ...
    }
}

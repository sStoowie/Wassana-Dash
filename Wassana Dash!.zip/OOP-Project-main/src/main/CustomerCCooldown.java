package main;




import java.util.Timer;
import java.util.TimerTask;

public class CustomerCCooldown {
    private Timer timer;
    private long cooldownDuration;
    public boolean finishedcustC = false;

    public CustomerCCooldown(long cooldownDuration) {
        this.cooldownDuration = cooldownDuration;
        this.timer = new Timer();
    }

    public void startCooldown() {
//        System.out.println("Cooldown started...");
        timer.schedule(new CooldownTask(), cooldownDuration);
    }
    public void cancelCooldown() {
        timer.cancel();
//        System.out.println("Mood Cooldown canceled.");
    }

    private class CooldownTask extends TimerTask {
        @Override
        public void run() {
//            System.out.println("Cooldown finished. Proceeding with the next task...");
            finishedcustC = true;
            // ...
        }
    }

}

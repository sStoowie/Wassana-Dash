import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame extends JFrame {
    private JButton helpButton;
    private JButton startButton;
    private JButton exitButton;

    public MyFrame() {
        setTitle("My Application");
        setSize(768, 576);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        // Set background image
        ImageIcon backgroundIcon = new ImageIcon("res/objects/menubg.png");
        JLabel backgroundLabel = new JLabel(backgroundIcon);
        backgroundLabel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundLabel);

        // Create buttons with custom icons
        helpButton = createButton("res/objects/mood2.png", 30, 100, 200, 50);
        startButton = createButton("res/objects/mood3.png", 30, 170, 200, 50);
        exitButton = createButton("res/objects/mood2.png", 30, 240, 200, 50);

        // Center buttons vertically
        int frameHeight = getHeight();
        int startY = (frameHeight - (50 * 3 + 20 * 2)) / 2;
        helpButton.setLocation(helpButton.getX(), startY);
        startButton.setLocation(startButton.getX(), startY + 70);
        exitButton.setLocation(exitButton.getX(), startY + 140);

        // Add buttons to the frame
        add(helpButton);
        add(startButton);
        add(exitButton);

        // Add GIF animation
        ImageIcon gifIcon = new ImageIcon("res/objects/noodlespin.gif");
        JLabel gifLabel = new JLabel(gifIcon);
        int gifWidth = (int) (gifIcon.getIconWidth() * 1.5);
        int gifHeight = (int) (gifIcon.getIconHeight() * 1.5);
        int gifX = getWidth() - gifWidth - 50; // Adjust the value to move the GIF to the right
        int gifY = (getHeight() - gifHeight) / 2;
        gifLabel.setBounds(gifX, gifY, gifWidth, gifHeight);
        add(gifLabel);

        // Start GIF animation
        ((ImageIcon) gifLabel.getIcon()).setImageObserver(gifLabel);

        Timer timer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gifLabel.repaint();
            }
        });
        timer.start();
    }

    private JButton createButton(String imagePath, int x, int y, int width, int height) {
        JButton button = new JButton();
        button.setBounds(x, y, width, height);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);

        // Set custom icon
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(image));

        // Set initial opacity
        button.setOpaque(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setButtonOpacity(button, 0.5f);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setButtonOpacity(button, 1.0f);
            }
        });

        // Button click listener
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle button click event
                if (button == helpButton) {
                    // Perform help action
                } else if (button == startButton) {
                    // Perform start action
                } else if (button == exitButton) {
                    // Perform exit action
                    System.exit(0);
                }
            }
        });

        return button;
    }

    private void setButtonOpacity(JButton button, float opacity) {
        button.setOpaque(opacity != 1.0f);
        button.setContentAreaFilled(opacity != 1.0f);
        button.setBackground(new Color(button.getBackground().getRed(),
                button.getBackground().getGreen(), button.getBackground().getBlue(), (int) (opacity * 255)));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MyFrame frame = new MyFrame();
                frame.setVisible(true);
            }
        });
    }
}

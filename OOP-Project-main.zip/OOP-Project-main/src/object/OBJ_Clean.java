
package object;

import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class OBJ_Clean extends SuperObject{
    public OBJ_Clean(){
        name = "Clean";
        width = 80;
        height = 80;
        try{
            image = ImageIO.read(new File("res/objects/clean.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
                collision = true;
        solidArea = new Rectangle();
        solidArea.x = 0;
        solidArea.y = 0;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 60;
        solidArea.height = 50;
    }
}

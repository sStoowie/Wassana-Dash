
package object;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Slot extends SuperObject{
    public Slot(){
        name = "slot";
        width = 150;
        height = 150;
        try{
            System.out.println("key");
            image = ImageIO.read(new File("res/objects/slot.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
        collision = false;
    }
}

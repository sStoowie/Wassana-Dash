
package main;

import javax.swing.JFrame;

public class Main {
    JFrame window = new JFrame();
    public Main(){
        
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(true);
        window.setTitle("game");
        
        GamePanel gamePanel = new GamePanel();
        window.add(gamePanel);
        
        //pack window w panel(window will have same size w panel)
        window.pack();
        
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        
        // set object and customer
        gamePanel.setupGame();
        //to make game loop
        gamePanel.startGameThread();
        
        
    }
}
